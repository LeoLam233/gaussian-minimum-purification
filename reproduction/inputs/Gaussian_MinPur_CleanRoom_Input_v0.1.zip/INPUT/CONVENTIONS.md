# Basic conventions available to the solver

This sheet fixes standard definitions for the question. It contains no proposed intermediate research results. You may use different consistent conventions, but give the conversion. The primary PDFs use their own notation and normalization.

## Bosons

For a canonical ordering of real quadratures, let

\[
[\hat r_j,\hat r_k]=i\Omega_{jk},\qquad
\Omega=\bigoplus_{j=1}^N\begin{pmatrix}0&1\\-1&0\end{pmatrix}.
\]

Write `d_j=Tr(rho r_j)` and use twice the usual statistical covariance,

\[
V_{jk}=\operatorname{Tr}\rho\{\hat r_j-d_j,\hat r_k-d_k\}.
\]

Thus the vacuum has `V=I`, physical covariances obey `V+i Omega >= 0`, and a pure Gaussian covariance obeys `V Omega V = Omega`. Gaussian states are determined by their first and second moments. A symplectic change of quadratures satisfies `S Omega S^T=Omega` and changes the covariance by `V -> S V S^T`.

The symplectic eigenvalues `nu_j` of a physical covariance obey `nu_j>=1`. The entropy of an `N`-mode Gaussian state is

\[
S=\sum_{j=1}^N b(\nu_j),\qquad
b(\nu)=\frac{\nu+1}{2}\log\frac{\nu+1}{2}
-\frac{\nu-1}{2}\log\frac{\nu-1}{2}.
\]

First moments are part of the state data even though this entropy formula depends only on the covariance. Justify any simplification you use in the optimization.

## Fermions

Let Hermitian Majorana operators obey `{c_j,c_k}=2 delta_jk` and define

\[
\Gamma_{jk}=\frac{i}{2}\operatorname{Tr}\rho[c_j,c_k].
\]

For parity-invariant quasifree states, `Gamma` is a real antisymmetric covariance that determines the state. Its eigenvalues are `+/- i lambda_j` with `0<=lambda_j<=1`; each `lambda_j` is one mode parameter. Purity is equivalent to `Gamma^2=-I`. Orthogonal changes of Majorana coordinates obey `Q Q^T=I` and transform it by `Gamma -> Q Gamma Q^T`. A choice of total-parity sector is an additional specification; do not silently identify all orthogonal maps with parity-preserving quadratic evolutions.

The entropy is

\[
S=\sum_{j=1}^N f(\lambda_j),\qquad
f(\lambda)=-\frac{1+\lambda}{2}\log\frac{1+\lambda}{2}
-\frac{1-\lambda}{2}\log\frac{1-\lambda}{2}.
\]

In both formulas use `0 log 0 = 0`. When using eigenvalues or singular values in code, count each mode once. State the convention by which a complete-mode subsystem's covariance and density operator are reduced.

These are standard covariance and entropy conventions; background is supplied by Windt et al., Sections 2-3 and 5.2, and Hackl-Bianchi, Sections 2-3 and 4.1. None of these definitions determines the answer to `TASK.md`.
