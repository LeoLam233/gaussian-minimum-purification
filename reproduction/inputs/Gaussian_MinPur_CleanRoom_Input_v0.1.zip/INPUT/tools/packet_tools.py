#!/usr/bin/env python3
"""Offline packet integrity and result archiving; no mathematical validation.

Python 3.9+, standard library only. Copyright (c) 2026 Dehao Lin. MIT License.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

MANIFEST = "MANIFEST.sha256"
PACKET_ROOT = Path(__file__).resolve().parent.parent


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def inventory(root):
    """List regular files without following links, junctions or reparse points."""
    if not root.is_dir():
        raise ValueError("Expected an existing directory")
    found = {}
    folded = set()

    def visit(directory):
        for item in sorted(directory.iterdir()):
            info = item.lstat()
            name = item.relative_to(root).as_posix()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise ValueError("Links/reparse points are not allowed: " + name)
            if name.casefold() in folded:
                raise ValueError("Case-insensitive name collision: " + name)
            folded.add(name.casefold())
            if stat.S_ISDIR(info.st_mode):
                visit(item)
            elif stat.S_ISREG(info.st_mode):
                found[name] = item
            else:
                raise ValueError("Non-regular item: " + name)

    visit(root)
    return found


def parse_manifest(raw):
    entries = {}
    folded = set()
    for number, line in enumerate(raw.decode("utf-8-sig").splitlines(), 1):
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            raise ValueError("Invalid manifest line " + str(number))
        digest, name = match.groups()
        parts = PurePosixPath(name).parts
        if (not parts or name.startswith("/") or "\\" in name or ":" in name
                or any(x in ("", ".", "..") for x in name.split("/"))
                or name == MANIFEST or name.casefold() in folded):
            raise ValueError("Unsafe/duplicate manifest path: " + name)
        entries[name] = digest
        folded.add(name.casefold())
    if not entries:
        raise ValueError("Empty manifest")
    return entries


def verify(root):
    files = inventory(root)
    if MANIFEST not in files:
        raise ValueError("Input manifest is missing")
    raw = files[MANIFEST].read_bytes()
    expected = parse_manifest(raw)
    actual = set(files) - {MANIFEST}
    if actual != set(expected):
        raise ValueError("Input inventory differs: missing="
                         + repr(sorted(set(expected) - actual))
                         + "; extra=" + repr(sorted(actual - set(expected))))
    for name, digest in expected.items():
        if sha256(files[name].read_bytes()) != digest:
            raise ValueError("Input hash mismatch: " + name)
    return {"status": "INPUT_INTEGRITY_OK", "checked_files": len(expected),
            "manifest_sha256": sha256(raw)}, raw


def overlap(first, second):
    return first == second or first in second.parents or second in first.parents


def validate_result(files):
    required = {"RESULT.md", "RUN_RECORD.json", "ACTION_LOG.jsonl"}
    if not required <= set(files):
        raise ValueError("Missing result files: " + repr(sorted(required - set(files))))
    if not files["RESULT.md"].decode("utf-8-sig").strip():
        raise ValueError("RESULT.md is empty")
    record = json.loads(files["RUN_RECORD.json"].decode("utf-8-sig"))
    fields = {"run_id", "model_or_service", "started_utc", "finished_utc", "outcome",
              "scope", "input_verification", "isolation", "prior_exposure",
              "comparison_material_seen_before_freeze", "deviations",
              "logging_limitations", "remaining_gaps"}
    if not isinstance(record, dict) or not fields <= set(record):
        raise ValueError("Incomplete RUN_RECORD.json; see OUTPUT_CONTRACT.md")
    for key in ("run_id", "model_or_service", "started_utc", "finished_utc",
                "input_verification", "prior_exposure", "logging_limitations"):
        if not isinstance(record[key], str) or not record[key].strip():
            raise ValueError("Expected nonempty text in run record: " + key)
    if record["outcome"] not in {"CLAIMED_PROOF", "CLAIMED_DISPROOF", "PARTIAL", "INPUT_BLOCKED"}:
        raise ValueError("Invalid solver outcome")
    for system in ("bosons", "fermions"):
        for claim in ("value", "attainment"):
            value = record.get("scope", {}).get(system, {}).get(claim)
            if value not in {"proved", "disproved", "unresolved"}:
                raise ValueError("Invalid scope status: " + system + "." + claim)
    if not isinstance(record["isolation"], dict):
        raise ValueError("Invalid isolation record")
    for key in ("network", "filesystem", "memory_and_context"):
        if not isinstance(record["isolation"].get(key), str) or not record["isolation"][key].strip():
            raise ValueError("Missing isolation observation: " + key)
    exposed = record["comparison_material_seen_before_freeze"]
    if not (isinstance(exposed, bool) or exposed == "unknown"):
        raise ValueError("Invalid comparison exposure field")
    for key in ("deviations", "remaining_gaps"):
        if not isinstance(record[key], list):
            raise ValueError("Expected a list: " + key)
    lines = files["ACTION_LOG.jsonl"].decode("utf-8-sig").splitlines()
    if not lines:
        raise ValueError("ACTION_LOG.jsonl is empty; disclose any logging limitation")
    for i, line in enumerate(lines, 1):
        event = json.loads(line)
        if (not isinstance(event, dict)
                or not {"time_utc", "action", "target", "result", "access_class"} <= set(event)
                or event["access_class"] not in {"allowed_input", "own_output", "runtime", "deviation"}):
            raise ValueError("Invalid action log line " + str(i))
    return record


def freeze(root, results, archive):
    results = results.resolve()
    archive = archive.resolve()
    if overlap(root, results):
        raise ValueError("Input and results must be separate, non-nested directories")
    if overlap(root, archive) or overlap(results, archive):
        raise ValueError("Archive must be outside both input and results directories")
    receipt = archive.with_name(archive.name + ".sha256")
    if archive.exists() or receipt.exists():
        raise ValueError("Refusing to overwrite an existing archive or receipt")
    verification, input_manifest = verify(root)
    snapshot = {name: path.read_bytes() for name, path in inventory(results).items()}
    record = validate_result(snapshot)
    frozen = {
        "format": "gaussian-minpur-cr0-result-v1",
        "frozen_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "run_id": record["run_id"],
        "input_verification": verification,
        "solver_outcome": record["outcome"],
        "mathematics_validated_by_this_tool": False,
        "isolation_validated_by_this_tool": False,
        "result_sha256": {name: sha256(data) for name, data in sorted(snapshot.items())},
    }
    # Detect ordinary edits during snapshotting. This is not a security boundary.
    again = inventory(results)
    if set(again) != set(snapshot) or any(again[n].read_bytes() != d for n, d in snapshot.items()):
        raise ValueError("Results changed during freezing; stop editing and retry")
    verification_after, manifest_after = verify(root)
    if verification_after != verification or manifest_after != input_manifest:
        raise ValueError("Input changed during freezing")
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("FREEZE_RECORD.json", json.dumps(frozen, indent=2, ensure_ascii=False) + "\n")
        z.writestr("INPUT_MANIFEST.sha256", input_manifest)
        for name, data in sorted(snapshot.items()):
            z.writestr("RESULT/" + name, data)
    digest = sha256(archive.read_bytes())
    with receipt.open("x", encoding="utf-8", newline="\n") as f:
        f.write(digest + "  " + archive.name + "\n")
    return {"status": "RESULT_SNAPSHOT_FROZEN", "archive": archive.name,
            "archive_sha256": digest, "result_files": len(snapshot),
            "mathematics_validated": False, "isolation_validated": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("verify", help="Verify the exact inventory and hashes of this input packet")
    fp = sub.add_parser("freeze", help="Archive solver output without judging the mathematics")
    fp.add_argument("--results", type=Path, required=True)
    fp.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "verify":
            result, _ = verify(PACKET_ROOT)
        else:
            result = freeze(PACKET_ROOT, args.results, args.archive)
    except (ValueError, OSError, UnicodeError, TypeError, AttributeError) as exc:
        # OSError often contains absolute paths; omit those from shareable logs.
        message = "Filesystem operation failed (" + type(exc).__name__ + ")" if isinstance(exc, OSError) else str(exc)
        print(json.dumps({"status": "ERROR", "message": message}, ensure_ascii=False))
        return 1
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
