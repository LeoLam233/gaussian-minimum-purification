# Offline primary sources

Both complete published papers are included. No source download is needed or permitted during the run. `SOURCES.json` identifies the versions, retrieval locations, licenses, page counts and SHA-256 hashes.

| ID | Paper | Included PDF | Entry points |
| --- | --- | --- | --- |
| WJEH2021 | B. Windt, A. Jahn, J. Eisert, L. Hackl, *Local optimization on pure Gaussian state manifolds*, SciPost Phys. 10, 066 (2021) | `Windt_et_al_SciPost_2021.pdf` (53 pages) | Section 6.1, page 43: the two distinct conjectures. Sections 2-3: Gaussian background. Section 5.2: Gaussian entanglement of purification. Section 6: the source's discussion and evidence. |
| HB2021 | L. Hackl, E. Bianchi, *Bosonic and fermionic Gaussian states from Kähler structures*, SciPost Phys. Core 4, 025 (2021) | `Hackl_Bianchi_SciPost_2021.pdf` (67 pages) | Sections 2-3: mathematical setting and Gaussian states. Section 4.1: subsystem and entropy definitions. Appendix A: conventions. |

The page numbers above refer to the actual included PDF pages (one-based), not search snippets or an arXiv/HTML version. For example, the WJEH2021 contents page has a different page locator for Section 6.1; the conjectures themselves appear on page 43. Use the actual pages when citing.

The full papers are available for consultation; there is no requirement to read all 120 pages linearly. They include material outside the target. Do not turn their conjectures, numerical evidence, or informal claims into assumed theorems. Resolve any ambiguity relevant to your argument explicitly.

Each PDF has a corresponding `_text.txt` file, mechanically extracted with page delimiters. These are search/navigation aids. Symbols, subscripts, columns, and mathematical layout may be lost or misordered in extraction; the original PDF is authoritative. No mathematical corrections or proof annotations were inserted into either paper. If an essential formula cannot be read in your environment, report the exact page rather than guessing.

The sources' bibliography entries, links, software references and supplementary download directions do not expand the allowed inputs. Use only the included papers and ordinary prior mathematical knowledge, or derive what you need yourself. This packet supplies no third-party mathematical code.

Both PDFs expressly carry CC BY 4.0 on their first page. They are redistributed unchanged with attribution; extracted text is a mechanical format conversion. The publication authors retain their copyright. The packet preparer does not claim their endorsement. See `../THIRD_PARTY_NOTICES.md` and the included license text.
