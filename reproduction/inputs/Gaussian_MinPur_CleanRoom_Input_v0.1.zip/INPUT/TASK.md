# The question

The source is Conjecture 2, called the minimum purification conjecture, in B. Windt, A. Jahn, J. Eisert and L. Hackl, *Local optimization on pure Gaussian state manifolds*, SciPost Physics 10, 066 (2021), DOI `10.21468/SciPostPhys.10.3.066`. The included published PDF states it in Section 6.1, printed/PDF page 43.

This packet specifies the following finite-mode version for independent investigation. It supplies the question, not a proposed solution.

## Domain and objective

Let `rho_AB` be a bipartite Gaussian state on `n_A` and `n_B` modes, where both numbers are finite nonnegative integers. A mode means one bosonic canonical pair or one fermionic complex mode (two Majorana coordinates).

- **Bosons:** normal Gaussian density operators of finitely many canonical modes, with finite covariance and finite first moments. Singular infinite-squeezing limits are not states in this domain.
- **Fermions:** parity-invariant quasifree density operators. Parity invariance means commuting with total fermion parity; it does not mean that a mixed state has support in only one parity sector. Pure Gaussian extensions of either definite total parity are allowed in the primary optimization. Superpositions of different parities are not added to this domain.

Include pure states and pure factors, repeated normal-mode parameters, and all physically allowed boundary values. Do not assume a strictly mixed or generic covariance unless you explicitly report the resulting restriction. The empty system may be treated separately.

For each pair of finite nonnegative integers `(m_A,m_B)`, let

\[
\mathcal P_{m_A,m_B}(\rho_{AB})
=\{\,|\Psi\rangle_{ABA'B'}:\ |\Psi\rangle\text{ is a pure Gaussian state},\,
\operatorname{Tr}_{A'B'}|\Psi\rangle\langle\Psi|=\rho_{AB},\,
N_{A'}=m_A,\ N_{B'}=m_B\,\}.
\]

The systems `A'` and `B'` consist of complete modes; the physical subsystems `A,B` and their prescribed marginal remain fixed. Both auxiliary sizes and all admissible pure Gaussian extensions are variable. Bosonic extensions must also be normal and have finite covariance. Use the ordinary reduced density operator of each mode subsystem for the entropy. State your fermionic mode ordering and reduction convention.

Define, using natural logarithms,

\[
E_P^{\mathrm G}(\rho_{AB})
=\inf_{m_A,m_B\in\mathbb N_0}\ 
\inf_{\Psi\in\mathcal P_{m_A,m_B}(\rho_{AB})}
S\!\left(\operatorname{Tr}_{BB'}|\Psi\rangle\langle\Psi|\right),
\qquad S(\sigma)=-\operatorname{Tr}(\sigma\log\sigma).
\]

An empty admissible set contributes `+infinity` to an infimum.

## Target to prove or refute

Determine whether, for every state in each domain above,

\[
E_P^{\mathrm G}(\rho_{AB})
\stackrel{?}{=}
\min_{\Psi\in\mathcal P_{n_A,n_B}(\rho_{AB})} S(\rho_{AA'}^{\Psi}).
\]

Report separately:

1. **Value:** whether allowing arbitrary finite auxiliary sizes can improve on the infimum with `m_A=n_A` and `m_B=n_B`.
2. **Attainment:** whether the infimum is achieved by an admissible extension of those matched sizes.

The target is universal, not an assertion about a selected family of input states or a selected parametrization. A positive answer must justify every restriction it makes on the allowed extensions. A negative answer must specify which part fails and give a verifiable counterexample or nonattainment argument. Local optimization outputs alone do not establish a global comparison.

The primary fermionic question includes both pure-state parity components. If you investigate a prescribed-parity variant as well, identify it as a separate variant and state its domain; it is not a prerequisite for completing the primary question.

## Scope limits

Do not assume or attempt to settle Conjecture 1 (whether Gaussian purifications are optimal among all, including non-Gaussian, purifications). The task does not request a closed formula for the minimum, an infinite-mode extension, or proof of convergence of a numerical optimizer. It also does not ask you to rediscover the problem selection or establish priority. Source attribution should still be precise.
