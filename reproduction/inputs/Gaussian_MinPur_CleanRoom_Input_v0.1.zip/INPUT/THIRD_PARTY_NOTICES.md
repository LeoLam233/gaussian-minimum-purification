# Attribution and licenses

## Primary papers

- Copyright B. Windt et al. (2021). Bennet Windt, Alexander Jahn, Jens Eisert and Lucas Hackl, *Local optimization on pure Gaussian state manifolds*, SciPost Physics 10, 066 (2021). DOI: https://doi.org/10.21468/SciPostPhys.10.3.066 . Published 11 March 2021. The included PDF was obtained from INSPIRE's public full-text archive. Its first page states Creative Commons Attribution 4.0 International. The PDF is unchanged; `_text.txt` is an automatically extracted navigation aid.
- Copyright L. Hackl and E. Bianchi (2021). Lucas Hackl and Eugenio Bianchi, *Bosonic and fermionic Gaussian states from Kähler structures*, SciPost Physics Core 4, 025 (2021). DOI: https://doi.org/10.21468/SciPostPhysCore.4.3.025 . Published 22 September 2021. The included PDF was obtained from the US National Science Foundation Public Access Repository. Its first page states Creative Commons Attribution 4.0 International. The PDF is unchanged; `_text.txt` is an automatically extracted navigation aid.

License identifier: CC-BY-4.0. License URL: https://creativecommons.org/licenses/by/4.0/ . The full license is included as `LICENSES/CC-BY-4.0.txt`. Source authors have not endorsed this task or any result produced from it. The retrieval URLs and byte hashes are recorded in `references/SOURCES.json`.

## Original packet material

The task specification, conventions summary and protocol documents were prepared with AI assistance. They are instructions and a statement of the research question, not evidence for its answer. Copyright (c) 2026 Dehao Lin. These original documents are made available under CC BY 4.0. The administrative code `tools/packet_tools.py` is made available under the MIT License in `LICENSES/MIT.txt`; it performs no mathematical calculation.

Third-party copyright remains with the respective authors. This licensing notice does not add any permitted source or authorize networking during the run.
