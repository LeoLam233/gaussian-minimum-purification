# Required output and freezing

Create a fresh sibling directory `RUN_OUTPUT/`. Do not create it inside `INPUT/`. Keep all work for this run there, including any scratch calculations worth retaining. Use relative paths in reports; omit personal device paths, credentials, or unrelated environment data.

Required files:

1. `RESULT.md`: state the mathematical conclusion separately for bosons and fermions, with value and attainment separated. Give a self-contained argument, counterexample, or exact residual. List every premise imported from a source with a page/section or equation locator and explain its role. Include checks, exceptions, and limitations. A remembered result absent from the supplied papers must be identified as such; a decisive nonstandard lemma needs a derivation here. Preserve a clear distinction between analytic proof and numerical evidence.
2. `RUN_RECORD.json`: machine-readable run information in the schema below. Replace each explanatory string with the actual observation. Use `unknown` where unavailable; do not guess. `outcome` must be one of `CLAIMED_PROOF`, `CLAIMED_DISPROOF`, `PARTIAL`, or `INPUT_BLOCKED`. These are the solver's claims, not externally validated verdicts.
3. `ACTION_LOG.jsonl`: a contemporaneous sequence of JSON objects, one per material read, tool call, computation, clarification, or access deviation. Each should have `time_utc`, `action`, `target`, `result`, and `access_class` (`allowed_input`, `own_output`, `runtime`, or `deviation`). Concise records are sufficient; a raw transcript may be added if available. This is an access/work record, not a requirement to expose private internal reasoning. Missing logging should be disclosed, not reconstructed as if observed.

Optional: `PROOF.tex`, experiment scripts, seeds, numerical output, failed approaches, and environment version information. Do not include installed packages, caches, previous work, or secrets. If no experiment was run, say so; code is not compulsory.

`RUN_RECORD.json` schema:

```json
{
  "run_id": "unique identifier chosen for this run",
  "model_or_service": "reported model/service, or unknown",
  "started_utc": "ISO 8601 timestamp, or unknown",
  "finished_utc": "ISO 8601 timestamp, or unknown",
  "outcome": "PARTIAL",
  "scope": {
    "bosons": {"value": "unresolved", "attainment": "unresolved"},
    "fermions": {"value": "unresolved", "attainment": "unresolved"}
  },
  "input_verification": "performed or not_performed, with reason",
  "isolation": {
    "network": "observed enforcement or unknown",
    "filesystem": "observed enforcement or unknown",
    "memory_and_context": "observed setup or unknown"
  },
  "prior_exposure": "recognition/prior exposure, none known, or unknown",
  "comparison_material_seen_before_freeze": false,
  "deviations": [],
  "logging_limitations": "actual limitations, or none known",
  "remaining_gaps": ["list actual mathematical gaps; use an empty array only if none are claimed"]
}
```

Use `proved`, `disproved`, or `unresolved` for each of the four scope entries. If a claim holds only under additional assumptions, use `unresolved` for the full target and explain the restricted result in `RESULT.md`. `comparison_material_seen_before_freeze` can also be `true` or `"unknown"`. An exposure or access violation is recorded honestly; it does not prevent preserving the attempted mathematics.

## Freeze before comparison

From the input directory, with Python 3.9 or later already installed:

```text
python tools/packet_tools.py verify
python tools/packet_tools.py freeze --results ../RUN_OUTPUT --archive ../RUN_FROZEN.zip
```

The freeze command verifies the unchanged input, reads only the input and the specified result directory, checks the required output structure, and writes a new archive and a SHA-256 receipt. It records the input-manifest hash and hashes of all result files. Existing archives/receipts are not overwritten. No network access or additional Python package is needed. The tool does not judge the mathematical content or verify the truth of a model's self-reported isolation.

Do not edit `RUN_OUTPUT` while it is being frozen. After freezing, preserve that archive and receipt. If comparison reveals errors, put the comparison and any corrections in a new phase/directory. Do not replace the original archive.

If this environment cannot run Python, deliver the three required files and all supporting outputs to the operator without seeing any comparison material. The operator can execute the same freeze command on that unchanged result before revealing anything. Record that the freeze was performed by the operator. A missing computational tool is not a mathematical disproof.
