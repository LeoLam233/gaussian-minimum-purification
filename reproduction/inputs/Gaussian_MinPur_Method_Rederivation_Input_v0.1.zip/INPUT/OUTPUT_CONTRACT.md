# Outputs for MR1: method-guided rederivation

Create a fresh sibling `RUN_OUTPUT/` directory. Preserve input files unchanged. Use relative research paths in records and omit unrelated personal/environment information.

## Required files

1. **RESULT.md**: a complete mathematical account or a precise partial result/counterexample. Begin by disclosing that the method framework was supplied. Give a node-by-node dependency table using G0, F1, F2, B1, B2, A_F, A_B, R; distinguish proved nodes, false proposed statements and unresolved steps. Write the new proofs, not just references back to the framework. List exact source premises and locators. State full-target scope separately for both statistics, value and attainment. Distinguish any conditional conclusion from an unconditional one. End with the strongest remaining objection or explain which checks resolved it.
2. **RUN_RECORD.json**: use the schema below. Do not copy explanatory placeholders as facts; use `unknown` for unavailable observations. An alleged completed proof is recorded as a claim pending review.
3. **ACTION_LOG.jsonl**: one JSON object per material read, tool use, computation or access deviation. Include `time_utc`, `action`, `target`, `result`, and `access_class` (`allowed_input`, `own_output`, `runtime`, or `deviation`). This is an access/work record, not a request for private internal reasoning. Disclose logging gaps rather than inventing a complete history.

Optional: a TeX manuscript, independently written diagnostics, seeds, numerical outputs and failed approaches. None is required merely to create the appearance of verification.

```json
{
  "run_id": "unique identifier for this fresh MR1 run",
  "model_or_service": "reported model/service or unknown",
  "started_utc": "ISO 8601 timestamp or unknown",
  "finished_utc": "ISO 8601 timestamp or unknown",
  "outcome": "PARTIAL",
  "scope": {
    "bosons": {"value": "unresolved", "attainment": "unresolved"},
    "fermions": {"value": "unresolved", "attainment": "unresolved"}
  },
  "proof_nodes": {
    "G0": "unresolved", "F1": "unresolved", "F2": "unresolved",
    "B1": "unresolved", "B2": "unresolved", "A_F": "unresolved",
    "A_B": "unresolved", "R": "unresolved"
  },
  "input_verification": "performed or not_performed, with details",
  "isolation": {
    "network": "observed enforcement or unknown",
    "filesystem": "observed enforcement or unknown",
    "memory_and_context": "observed setup or unknown"
  },
  "method_framework_supplied": true,
  "full_manuscript_seen_before_freeze": false,
  "comparison_material_seen_before_freeze": true,
  "prior_exposure": "supplied framework acknowledged; disclose any other recognized solution or prior exposure",
  "deviations": [],
  "logging_limitations": "actual limitations or none known",
  "remaining_gaps": ["list actual gaps; empty only if none are claimed"]
}
```

The outcome choices are `CLAIMED_PROOF`, `CLAIMED_DISPROOF`, `PARTIAL`, or `INPUT_BLOCKED`. Scope entries use `proved`, `disproved`, or `unresolved`. Proof nodes use `proved`, `refuted`, or `unresolved`. A refuted proposed route is not automatically a refuted main theorem. An alternative proof can discharge a node if it establishes the exact obligation; explain the change.

Because the framework has been supplied, `method_framework_supplied` and `comparison_material_seen_before_freeze` must both be `true`. The latter records method exposure, not that the full manuscript was read. `full_manuscript_seen_before_freeze` records that separate observation and can be `true`, `false`, or `"unknown"`. Preserve a run honestly even if unintended exposure occurs, and disclose its effect on the independence claim.

## Freeze

With Python 3.9+ already installed, run from `INPUT/`:

```text
python tools/packet_tools.py verify
python tools/packet_tools.py freeze --results ../RUN_OUTPUT --archive ../MR1_RUN_FROZEN.zip
```

The standard-library-only tool verifies this packet's exact inventory and hashes, checks output structure and method-exposure fields, and writes a new result archive and SHA-256 receipt. Its freeze record identifies the method-guided phase. It does not validate the mathematics, the truth of an access log, or technical isolation.

Stop editing results while freezing. Do not overwrite the archive. Freeze before seeing another model's reconstruction, the existing full manuscript, or feedback on your result. Any later exposure/revision is a separate recorded phase. If this environment cannot execute Python, deliver the complete outputs unchanged to the operator for freezing before such feedback; record that limitation.
