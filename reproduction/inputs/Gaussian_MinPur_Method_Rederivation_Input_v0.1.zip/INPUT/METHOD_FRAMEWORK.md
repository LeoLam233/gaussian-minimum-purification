# Proposed architecture and proof obligations

**Status:** supplied method information, not established research premises. This sheet deliberately reveals the candidate proof architecture. The proposed route was extracted from an existing AI-assisted argument, with an additional attainment route from a separate partial derivation. Neither source's full proof is supplied or may be assumed correct.

The universal target and domain remain those of `TASK.md`. Normal forms, entropy formulas and ordinary linear algebra may be used from the declared background. Everything below that goes beyond those standard facts must be proved in this run.

## Dependency map

| Node | Obligation | What is insufficient |
| --- | --- | --- |
| G0 | Establish conventions, local operations and nonemptiness of the fixed-total classes used later | Assuming the optimal auxiliary size |
| F1 | Fermionic local entropy compression | A bound that activates only above the mixed-mode count of the entire physical state |
| F2 | Equality in the selected fermionic compression forces a pure factor | Entropy inequality alone |
| B1 | Bosonic local entropy compression with a physically valid auxiliary split | Interlacing for a matrix not identified with the actual retained subsystem |
| B2 | Equality in the selected bosonic compression forces a pure factor | Claiming that equality of two entropies always implies factorization |
| A_F | Attainment at each fixed finite auxiliary total, with all splits allowed, for fermions | Merely producing feasible purifications |
| A_B | The same attainment for bosons | Treating the symplectic group or all pure covariances as compact |
| R | Reduce all finite auxiliary totals and reach the matched split | Moving a mode without justifying when it can be deleted |

The local compression nodes and the attainment nodes can be derived separately. Node R must be conditional until its required local inequality, equality and attainment statements have actually been established.

## G0: setup

Write `n=n_A+n_B`. At fixed total auxiliary count `M>=n`, define `e_M` initially as the infimum of the cut entropy over all admissible pure Gaussian extensions with `M` auxiliary modes and over all splits `k+(M-k)`, `0<=k<=M`. Prove nonemptiness from a canonical purification and pure-mode padding. Do not call `e_M` a minimum until attainment is justified.

Account for first moments in the bosonic case. In the primary fermionic domain both definite pure-state total parities are allowed; this is not permission to form coherent superpositions of parities. Distinguish changes of coordinates, unitary operations, and mere representations used to compute a spectrum.

## F1/F2 and B1/B2: the proposed local statement

Let `rho_XC` be a possibly mixed Gaussian state in the task's domain, with `a` physical modes in `X` and `c>a` auxiliary modes in `C`. The proposed statement is that a Gaussian transformation on `C` alone permits a complete-mode split

\[
C=\widetilde C\oplus P,\qquad N_P=1,
\]

such that

\[
S(X\widetilde C)\le S(XC).
\]

For the mode selected by the proposed construction, the proposed equality assertion is

\[
S(X\widetilde C)=S(XC)
\quad\Longleftrightarrow\quad
\rho_{XC}=\rho_{X\widetilde C}\otimes|\chi\rangle\langle\chi|_P.
\]

Interpret fermionic factorization with the complete-mode/CAR convention of the task. The assertion concerns the specifically constructed mode; it is not an assertion that arbitrary equal-entropy partial traces force purity. It must apply to mixed `rho_XC`, because it will later be used on a reduction of a larger pure state.

### Geometric selection hint

Set `d=a+c`. On the real `2d`-dimensional coefficient space, construct from a normal form a genuine complex structure `J`, satisfying `J^2=-I`, adapted to the joint state. This is not the generally nonsquaring-to-minus-identity covariance map sometimes called the complex structure of a mixed state.

Let `C_math` denote the real `2c`-dimensional coefficient subspace of the auxiliary modes. Consider

\[
L=C_{\rm math}\cap J C_{\rm math}.
\]

The proposed dimension argument is `dim_R L >= 2(c-a)>0`. Check the bound and `J`-invariance. Then examine a real two-plane spanned by `v,Jv` inside `C_math`. Prove that it is a physical single-mode plane in the relevant statistics and that its complement can be realized by a coordinate change restricted to `C`.

### Fermionic spectral route

Starting from the real skew normal form of the joint covariance, construct an orthogonal `J` and a commuting positive Hermitian operator `K` with spectrum in `[0,1]` and `Gamma=J K`. Supply your formulas and verify every identity. Do not invert a covariance that may have zero modes.

Use `J` to regard the real space as a complex space and remove one complex line. Prove that compression of `K` to the retained complex hyperplane supplies the mode parameters of the actual reduced covariance. Track each mode once rather than counting both real coordinates or both spectral signs.

Use Hermitian eigenvalue interlacing and the one-mode entropy function to prove the inequality. Determine the correct end of the interlacing interval yourself. For equality, identify all vanishing nonnegative terms, then use the trace difference on the removed complex line and a positive-semidefinite operator to establish a pure, decoupled covariance block. Prove factorization, not just a particular value of a diagonal matrix entry.

### Bosonic spectral route

Start from a Williamson form of the joint covariance. Construct `J` on observable **coefficient vectors** so that it is symplectic, `Omega J` is positive definite, and the covariance bilinear form is `J`-invariant. Derive the formula rather than importing a transformation law for operator columns without checking transposes.

Prove that the selected real two-plane is symplectic, its symplectic complement is `J`-invariant, and the split can be made entirely within `C`. Normal-form coordinates may be used for spectral calculations, but a global transformation of `X C` is not an allowed operation on the prescribed physical marginal.

Identify the actual retained covariance, together with its commutator form, with a positive Hermitian compression. Prove that its complex eigenvalues are exactly the retained symplectic eigenvalues. Then derive the entropy inequality and equality rigidity using the appropriate side of interlacing, trace information and positivity. Do not assume that the fermionic interlacing direction carries over unchanged.

For both statistics, cover pure factors, repeated normal-mode parameters, and allowed zero parameters without a generic-spectrum assumption. If a proposed step fails, give the smallest explicit obstruction rather than assuming continuity repairs it.

## A_F / A_B: fixed-total attainment

At each fixed `M` and split `k+(M-k)`, establish that a nonempty feasible class attains its entropy infimum. A finite number of splits then gives attainment for `e_M`.

For fermions, a direct closed-and-bounded argument for pure covariances with the physical block fixed is a candidate route. Alternatively, use a reference purification and compact auxiliary transformations/cuts, but prove the parametrization covers the entire variational class being minimized over.

For bosons, one candidate route is to control auxiliary marginal entropies along a bounded-objective minimizing sequence, and normalize each auxiliary marginal by separate local Williamson transformations. Determine whether this bounds all covariance entries, whether the fixed marginal and purity survive a limit, and whether that limit remains a normal finite-covariance state. Establish the needed entropy inequalities and continuity; do not cite this paragraph as a compactness theorem.

An alternative route uses the space of symplectic auxiliary cuts of a fixed reference purification. If using it, prove auxiliary-orbit completeness and frame independence, and exclude finite-entropy escape toward a degenerate restricted symplectic form. Either route is acceptable, but its prerequisites must be included in the new derivation.

## R: from local compression to the matched theorem

After proving attainment, take a fixed-`M` minimizer while allowing all auxiliary splits.

The proposed reduction is:

1. If `M>n`, at least one auxiliary side has more modes than its corresponding physical side. Apply the local statement to that side's reduced, generally mixed state.
2. Keep the full pure extension and **reassign** the selected mode to the opposite auxiliary party. Check that this is an admissible competitor for the same fixed-`M` problem.
3. Combine its entropy inequality with fixed-total optimality. If equality follows, use the proved equality condition to obtain a pure marginal for the selected mode. Justify why it then factors from the **entire extension**, so that actual deletion preserves the required physical state.
4. Compare `e_M` and `e_(M-1)` in both directions, including padding by independent pure modes. Do not reverse a variational inequality.
5. At total `n`, show that transfers terminate at exactly `(n_A,n_B)` while preserving the optimum. Cover auxiliary totals below `n` as well, and separate the empty-system case if needed.

Supply the complete argument and its quantifiers. A proof only of the inequality in F1/B1, or only of finite-size attainment, does not close R.

## What this framework does and does not establish

This sheet supplies the geometric idea, proposed equality mechanism, attainment routes and global architecture. These shared ideas must be acknowledged when describing the output's independence. Successful reconstruction would not be independent discovery of those ideas.

The sheet supplies no detailed matrix proof, numerical answers, executable mathematical implementation or verdict to inherit. A successful result requires you to derive and check the proposed mechanisms. A concrete defect or a precise unresolved node remains a legitimate outcome.
